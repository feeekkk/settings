define([
	'marionette',
	'tpl!templates/${NAME}.tpl'
], function(
	Mn,
	tpl
) {
	var ${NAME} = Mn.ItemView.extend({
		template: tpl,

		templateHelpers: function() {
			return {

			}
		},

		events: {
		},

		ui: {
		},

		initialize: function(options) {
		}
	});

	return ${NAME};
});